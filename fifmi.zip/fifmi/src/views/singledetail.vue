<template>
<div>
 <!-- Page Inner -->
        <section class="innersec">
            <div class="container">
                <div class="row">
                    <div class="col-12 col-md-12">
                        <div class="toptitle text-center">
                            <h2>Single Detail</h2>
                            <nav>
                                <ol class="breadcrumb bg-transparent p-0 justify-content-center font-weight-bold">
                                    <li class="breadcrumb-item"><router-link to="/ ">Home</router-link></li>
                                    <li class="breadcrumb-item active">Single Detail</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Page Inner -->

        <!-- Single Detail -->
        <section class="singlesec py-5">
            <div class="container">
                <div class="row">
                    <div class="col-12 col-lg-9 mb-5 mb-lg-0">
                        <div class="single-news">
                            <div class="singleimage shrink-effect gradient-full">
                                <img src="../assets/images/news1.jpg" alt="" class="img-fluid w-100" />
                            </div>
                            <div class="single-title text-center my-4">
                                <h4>Apostles Update Week 27</h4>
                                <div class="author text-dark font-weight-bold">
                                    <span><i class="fa fa-user-o"></i> admin on</span>
                                    <span><i class="fa fa-calendar"></i> June 12, 2011</span>
                                    <span><i class="fa fa-clock-o"></i> 16:48 </span>
                                </div>
                            </div>
                            <p>Dear Friends</p>
                            <h5>Toronto, Canada</h5>
                            <p class="text-justify">We want to thank God for the resounding success of the FIRST EVER Canada Deeper Life Leadership Conference held from July 5-8, 2018. The grace of God was abounding as our father and mother, the apostles Prof Ezekiel & Dr. Eunor Guti were able to attend the conference.</p>
                            <p class="text-justify">Over 100 leaders of Forward in Faith churches from across the country made great sacrifices to attend this historic, life-changing event, learning at the feet of our father and mother, the Apostles of Jesus Christ.</p>
                            <p class="text-justify">Hosted by our National Administrator Overseers Sheddy and Ree Mbizvo, the God of Ezekiel gave Baba supernatural strength as he presided over almost every session of the conference, imparting wisdom and spiritual gifts to the leaders of Canada along with powerful speakers from around the world, including successful international businessman Elder Timothy Matangi, Overseers Drs. Stanley & Tafadzwa Masaka, Pastors Paul & Fiona Arthurs and Deputy Secretary General Drs. Steve & La-Verne Simukai. </p>
                            <p class="text-justify">Following powerful teachings on the importance of missions, there was great celebration as our nation BROKE THE RECORD participating in missions and joining our father and mother to send the gospel around the world!</p>
                            <p class="text-justify">The venue was overflowing by Saturday night when about 200 adults and 45 children attended the official opening service which was open to the public and featured Canadians from countries around the world including Fiji, Botswana, Namibia, Cameroon, the Caribbean and native Canadians who took turns to welcome Baba and Amai to Canada and thank them for the gospel that saved us.</p>
                            <hr>
                            <h6>Teaching:  Part Of Baba & Amai’s Message</h6>
                            <p class="text-justify">First of all we need to be sure of our own salvation. Are you really born again in your spirit? You should fear God and fear to sin. Spiritual growth happens after the seed drops in your spirit and grows. Sanctification is a process. God gives gifts through the Holy Spirit then later you separate from the one who gave you the gift. Corinthians chapter 12 talks about gifts of the spirit and chapter 13 talks about how it doesn't matter what kind of tongues - to show that you can speak in tongues without connecting to the giver of the gift. You know you have the spirit of God by love, not tongues. You've been saved but you must continue being saved. Read the word, pray. Jn 1:4 "In Him was life, and the life was the light of men". When Jesus is in you, you see what others don't see. We need to be saved. God bless you.</p>
                            <hr>
                            <b class="text-dark">We love you and are praying for you, Drs Steve & La-Verne Simukai</b>
                            <div class="single-contact-detail my-3">
                                <div class="row no-gutters">
                                    <div class="col-12 col-md-4">
                                        <div class="single-contact text-center">
                                            <div class="single-contact-icon rounded-50 mx-auto mb-2">
                                                <i class="fa fa-map-marker"></i>
                                            </div>
                                            <div class="single-contact-txt">
                                                <span>Zaoga Forward In Faith Ministries Int.</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12 col-md-4">
                                        <div class="single-contact text-center">
                                            <div class="single-contact-icon rounded-50 mx-auto mb-2">
                                                <i class="fa fa-phone"></i>
                                            </div>
                                            <div class="single-contact-txt">
                                                <span class="d-block"><a href="tel:+263 777 282 356" class="text-light">+263 777 282 356</a></span>
                                                <span class="d-block"><a href="tel:+263 777 282 356" class="text-light">+263 777 282 092</a></span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12 col-md-4">
                                        <div class="single-contact text-center">
                                            <div class="single-contact-icon rounded-50 mx-auto mb-2">
                                                <i class="fa fa-envelope"></i>
                                            </div>
                                            <div class="single-contact-txt">
                                                <span class="d-block"><a href="mailto:info@fifmi.org" class="text-light">info@fifmi.org</a></span>
                                                <span class="d-block"><a href="mailto:www.fifmi.org" class="text-light">www.fifmi.org</a></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <h5>Category:</h5>
                            <div class="category">
                                <a href="#" class="text-light float-sm-left">Apostles</a>
                                <a href="#" class="text-light float-sm-right"> Updates</a>
                            </div>
                            <div class="user-comment-media my-4">
                                <h4 class="pb-4">03 Comments</h4>
                                <div class="media mb-4">
                                    <img src="../assets/images/img2.jpg" alt="" class="img-fluid rounded-50 d-flex mr-4">
                                    <div class="media-body">
                                        <a href="#" class="btn-reply float-sm-right text-dark font-weight-bold mb-2 mb-sm-0 d-inline-block">Reply <i class="fa fa-mail-reply"></i></a>
                                        <a href="#"><h6 class="mb-2">St Kitts <span class="date font-weight-normal text-primary">July 9, 2018</span></h6></a>
                                        We had 3 visitors who promised to come back. Our attendance was 22 (20 adults and 2 children). One person received Jesus Christ as their personal Savior.
                                    </div>
                                </div>
                                <div class="media mb-4">
                                    <img src="../assets/images/img2.jpg" alt="" class="img-fluid rounded-50 d-flex mr-4">
                                    <div class="media-body">
                                        <a href="#" class="btn-reply float-sm-right text-dark font-weight-bold mb-2 mb-sm-0 d-inline-block">Reply <i class="fa fa-mail-reply"></i></a>
                                        <a href="#"><h6 class="mb-2">St Kitts <span class="date font-weight-normal text-primary">July 9, 2018</span></h6></a>
                                        We had 3 visitors who promised to come back. Our attendance was 22 (20 adults and 2 children). One person received Jesus Christ as their personal Savior.
                                    </div>
                                </div>
                                <div class="media mb-4">
                                    <img src="../assets/images/img2.jpg" alt="" class="img-fluid rounded-50 d-flex mr-4">
                                    <div class="media-body border-0">
                                        <a href="#" class="btn-reply float-sm-right text-dark font-weight-bold mb-2 mb-sm-0 d-inline-block">Reply <i class="fa fa-mail-reply"></i></a>
                                        <a href="#"><h6 class="mb-2">St Kitts <span class="date font-weight-normal text-primary">July 9, 2018</span></h6></a>
                                        We had 3 visitors who promised to come back. Our attendance was 22 (20 adults and 2 children). One person received Jesus Christ as their personal Savior.
                                    </div>
                                </div>
                                <hr>
                            </div>
                            <div class="user-comment-form">
                                <h4 class="pb-4">Write Your Comments</h4>
                                <form>
                                    <div class="row">
                                        <div class="col-12 col-md-6">
                                            <div class="form-group">
                                                <input type="text" class="form-control" placeholder="Name :">
                                            </div>
                                        </div>
                                        <div class="col-12 col-md-6">
                                            <div class="form-group">
                                                <input type="text" class="form-control" placeholder="Email :">
                                            </div>
                                        </div>
                                        <div class="col-12 col-md-12">
                                            <div class="form-group">
                                                <textarea class="form-control" placeholder="Message :"></textarea>
                                            </div>
                                        </div>
                                        <div class="col-12 col-md-4">
                                            <button type="submit" class="btn btn-primary btn-lg rounded-0">Post Comment</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-lg-3">
                        <div class="right-title">
                            <h5>Ezekiel Tv</h5>
                            <a href="#" class="right-newsimg"><img src="../assets/images/news.jpg" alt="" class="img-fluid" /></a>
                        </div>
                        <hr>
                        <div class="eventdiv">
                            <a href="#"><img src="../assets/images/event.jpg" alt="" class="img-fluid" /></a>
                        </div>
                        <hr>
                        <div class="right-title">
                            <h5>Account Login</h5>
                            <form class="login-form">
                                <div class="form-group position-relative">
                                    <input type="email" name="email" placeholder="Email" class="form-control pr-4" />
                                    <span class="formicon"><i class="fa fa-user"></i></span>
                                </div>
                                <div class="form-group position-relative">
                                    <input type="password" name="password" placeholder="Password" class="form-control pr-4" />
                                    <span class="formicon"><i class="fa fa-lock"></i></span>
                                </div>
                                <div class="form-group-btn">
                                    <input type="submit" value="Login" class="btn btn-primary text-uppercase btn-block rounded-0 mb-1" />
                                </div>
                            </form>
                            <div class="text-dark text-center">
                                Create an account <a href="#"><u>Register</u></a>
                            </div>
                        </div>
                        <hr>
                        <div class="right-title">
                            <h5>Recent Comments</h5>
                            <ul class="list-unstyled mb-0 comment-list">
                                <li>
                                    <a href="#" class="text-light">
                                        <div class="commentimg shrink-effect float-left mr-3">
                                            <img src="../assets/images/comment.jpg" alt="" class="img-fluid" />
                                        </div>
                                        <div class="comment-txt">
                                            <h6 class="mb-1">Glory be to the Almighty God</h6>
                                            <span><i class="fa fa-calendar"></i> 2 years 45 weeks ago</span>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" class="text-light">
                                        <div class="commentimg shrink-effect float-left mr-3">
                                            <img src="../assets/images/comment.jpg" alt="" class="img-fluid" />
                                        </div>
                                        <div class="comment-txt">
                                            <h6 class="mb-1">Glory be to the Almighty God</h6>
                                            <span><i class="fa fa-calendar"></i> 2 years 45 weeks ago</span>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" class="text-light">
                                        <div class="commentimg shrink-effect float-left mr-3">
                                            <img src="../assets/images/comment.jpg" alt="" class="img-fluid" />
                                        </div>
                                        <div class="comment-txt">
                                            <h6 class="mb-1">Glory be to the Almighty God</h6>
                                            <span><i class="fa fa-calendar"></i> 2 years 45 weeks ago</span>
                                        </div>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Single Detail -->

</div>
</template>
