<template>
<div>
 <!-- Page Inner -->
        <section class="innersec">
            <div class="container">
                <div class="row">
                    <div class="col-12 col-md-12">
                        <div class="toptitle text-center">
                            <h2>Media</h2>
                            <nav>
                                <ol class="breadcrumb bg-transparent p-0 justify-content-center font-weight-bold">
                                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                                    <li class="breadcrumb-item active">Media</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Page Inner -->

        <!-- Media -->
        <section class="mediasec py-5">
            <div class="container">
                <div class="row">
                    <div class="col-12 col-lg-9 mb-5 mb-lg-0">
                        <div class="media-gallery">
                            <div class="button-group filters-button-group mb-4">
                                <button class="button filter-button active" data-filter="all">All</button>
                                <button class="button filter-button" data-filter="Explos">Explos</button>
                                <button class="button filter-button" data-filter="Projects">Projects And Sites </button>
                                <button class="button filter-button" data-filter="Apostles">Apostles</button>
                                <!-- <button class="button filter-button" data-filter="Events">Events</button> -->
                            </div>
                            <div id="lightgallery" class="demo-gallery">
                                <div class="grid row">
                                    <div class="col-12 col-sm-6 col-lg-6 filter Explos">
                                        <div class="gallery-item position-relative">
                                            <div class="gallery-image gradient-bt">
                                                <img class="img-fluid img-lg" src="../assets/images/news1.jpg" alt="">
                                            </div>
                                            <div class="gallery-overlay w-100 h-100 text-center">
                                                <div class="content d-table w-100 h-100">
                                                    <div class="content d-table-cell w-100 h-100 align-middle">
                                                        <div class="popup-gallery bg-white rounded-50 mx-auto">
                                                            <a href="images/news1.jpg" class="text-light"><i class="fa fa-plus popup-btn"></i></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12 col-sm-6 col-lg-3 filter Projects">
                                        <div class="gallery-item position-relative">
                                            <div class="gallery-image gradient-bt">
                                                <img class="img-fluid img-sm" src="../assets/images/news2.jpg" alt="">
                                            </div>
                                            <div class="gallery-overlay w-100 h-100 text-center">
                                                <div class="content d-table w-100 h-100">
                                                    <div class="content d-table-cell w-100 h-100 align-middle">
                                                        <div class="popup-gallery bg-white rounded-50 mx-auto">
                                                            <a href="images/news2.jpg" class="text-light"><img src="../assets/images/ezikel.png" alt="" class="img-fluid" /></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="gallery-item position-relative">
                                            <div class="gallery-image gradient-bt">
                                                <img class="img-fluid img-sm" src="../assets/images/news3.jpg" alt="">
                                            </div>
                                            <div class="gallery-overlay w-100 h-100 text-center">
                                                <div class="content d-table w-100 h-100">
                                                    <div class="content d-table-cell w-100 h-100 align-middle">
                                                        <div class="popup-gallery bg-white rounded-50 mx-auto">
                                                            <a href="images/news3.jpg" class="text-light"><img src="../assets/images/ezikel.png" alt="" class="img-fluid" /></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12 col-sm-6 col-lg-3 filter Apostles">
                                        <div class="gallery-item position-relative">
                                            <div class="gallery-image gradient-bt">
                                                <img class="img-fluid img-sm" src="../assets/images/news2.jpg" alt="">
                                            </div>
                                            <div class="gallery-overlay w-100 h-100 text-center">
                                                <div class="content d-table w-100 h-100">
                                                    <div class="content d-table-cell w-100 h-100 align-middle">
                                                        <div class="popup-youtube bg-white rounded-50 mx-auto">
                                                            <a href="http://www.youtube.com/watch?v=0O2aH4XLbto" class="text-light"><i class="fa fa-play"></i></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="gallery-item position-relative">
                                            <div class="gallery-image gradient-bt">
                                                <img class="img-fluid img-sm" src="../assets/images/news3.jpg" alt="">
                                            </div>
                                            <div class="gallery-overlay w-100 h-100 text-center">
                                                <div class="content d-table w-100 h-100">
                                                    <div class="content d-table-cell w-100 h-100 align-middle">
                                                        <div class="popup-youtube bg-white rounded-50 mx-auto">
                                                            <a href="http://www.youtube.com/watch?v=0O2aH4XLbto" class="text-light"><i class="fa fa-play"></i></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12 col-sm-6 col-lg-3 filter Projects">
                                        <div class="gallery-item position-relative">
                                            <div class="gallery-image gradient-bt">
                                                <img class="img-fluid img-sm" src="../assets/images/news2.jpg" alt="">
                                            </div>
                                            <div class="gallery-overlay w-100 h-100 text-center">
                                                <div class="content d-table w-100 h-100">
                                                    <div class="content d-table-cell w-100 h-100 align-middle">
                                                        <div class="popup-gallery bg-white rounded-50 mx-auto">
                                                            <a href="images/news2.jpg" class="text-light"><img src="../assets/images/ezikel.png" alt="" class="img-fluid" /></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="gallery-item position-relative">
                                            <div class="gallery-image gradient-bt">
                                                <img class="img-fluid img-sm" src="../assets/images/news3.jpg" alt="">
                                            </div>
                                            <div class="gallery-overlay w-100 h-100 text-center">
                                                <div class="content d-table w-100 h-100">
                                                    <div class="content d-table-cell w-100 h-100 align-middle">
                                                        <div class="popup-gallery bg-white rounded-50 mx-auto">
                                                            <a href="images/news3.jpg" class="text-light"><img src="../assets/images/ezikel.png" alt="" class="img-fluid" /></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12 col-sm-6 col-lg-3 filter Apostles">
                                        <div class="gallery-item position-relative">
                                            <div class="gallery-image gradient-bt">
                                                <img class="img-fluid img-sm" src="../assets/images/news2.jpg" alt="">
                                            </div>
                                            <div class="gallery-overlay w-100 h-100 text-center">
                                                <div class="content d-table w-100 h-100">
                                                    <div class="content d-table-cell w-100 h-100 align-middle">
                                                        <div class="popup-youtube bg-white rounded-50 mx-auto">
                                                            <a href="http://www.youtube.com/watch?v=0O2aH4XLbto" class="text-light"><i class="fa fa-play"></i></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="gallery-item position-relative">
                                            <div class="gallery-image gradient-bt">
                                                <img class="img-fluid img-sm" src="../assets/images/news3.jpg" alt="">
                                            </div>
                                            <div class="gallery-overlay w-100 h-100 text-center">
                                                <div class="content d-table w-100 h-100">
                                                    <div class="content d-table-cell w-100 h-100 align-middle">
                                                        <div class="popup-youtube bg-white rounded-50 mx-auto">
                                                            <a href="http://www.youtube.com/watch?v=0O2aH4XLbto" class="text-light"><i class="fa fa-play"></i></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12 col-sm-6 col-lg-6 filter Explos">
                                        <div class="gallery-item position-relative">
                                            <div class="gallery-image gradient-bt">
                                                <img class="img-fluid img-lg" src="../assets/images/news1.jpg" alt="">
                                            </div>
                                            <div class="gallery-overlay w-100 h-100 text-center">
                                                <div class="content d-table w-100 h-100">
                                                    <div class="content d-table-cell w-100 h-100 align-middle">
                                                        <div class="popup-gallery bg-white rounded-50 mx-auto">
                                                            <a href="images/news1.jpg" class="text-light"><i class="fa fa-plus popup-btn"></i></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                               </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-lg-3">
                        <div class="right-title">
                            <h5>Ezekiel Tv</h5>
                            <a href="#" class="right-newsimg"><img src="../assets/images/news.jpg" alt="" class="img-fluid" /></a>
                        </div>
                        <hr>
                        <div class="eventdiv">
                            <a href="#"><img src="../assets/images/event.jpg" alt="" class="img-fluid" /></a>
                        </div>
                        <hr>
                        <div class="right-title">
                            <h5>Account Login</h5>
                            <form class="login-form">
                                <div class="form-group position-relative">
                                    <input type="email" name="email" placeholder="Email" class="form-control pr-4" />
                                    <span class="formicon"><i class="fa fa-user"></i></span>
                                </div>
                                <div class="form-group position-relative">
                                    <input type="password" name="password" placeholder="Password" class="form-control pr-4" />
                                    <span class="formicon"><i class="fa fa-lock"></i></span>
                                </div>
                                <div class="form-group-btn">
                                    <input type="submit" value="Login" class="btn btn-primary text-uppercase btn-block rounded-0 mb-1" />
                                </div>
                            </form>
                            <div class="text-dark text-center">
                                Create an account <a href="#"><u>Register</u></a>
                            </div>
                        </div>
                        <hr>
                        <div class="right-title">
                            <h5>Recent Comments</h5>
                            <ul class="list-unstyled mb-0 comment-list">
                                <li>
                                    <a href="#" class="text-light">
                                        <div class="commentimg shrink-effect float-left mr-3">
                                            <img src="../assets/images/comment.jpg" alt="" class="img-fluid" />
                                        </div>
                                        <div class="comment-txt">
                                            <h6 class="mb-1">Glory be to the Almighty God</h6>
                                            <span><i class="fa fa-calendar"></i> 2 years 45 weeks ago</span>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" class="text-light">
                                        <div class="commentimg shrink-effect float-left mr-3">
                                            <img src="../assets/images/comment.jpg" alt="" class="img-fluid" />
                                        </div>
                                        <div class="comment-txt">
                                            <h6 class="mb-1">Glory be to the Almighty God</h6>
                                            <span><i class="fa fa-calendar"></i> 2 years 45 weeks ago</span>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" class="text-light">
                                        <div class="commentimg shrink-effect float-left mr-3">
                                            <img src="../assets/images/comment.jpg" alt="" class="img-fluid" />
                                        </div>
                                        <div class="comment-txt">
                                            <h6 class="mb-1">Glory be to the Almighty God</h6>
                                            <span><i class="fa fa-calendar"></i> 2 years 45 weeks ago</span>
                                        </div>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Media -->
</div>
</template>

<script>
import $ from 'jquery'

export default {
  name: '',
 data(){
 return {
   value: "",
 }
},
mounted(){
    $(document).ready(function(){
        $(".filter-button").click(function(){
            this.value = $(this).attr('data-filter');
            $('.filter-button').removeClass('active');
            $(this).addClass('active');
            if(this.value == "all")
            {
                $('.filter').show('1000');
            }
            else{
                $('.filter').removeClass('active');    
                $(".filter").not('.'+this.value).hide('3000');
                $('.filter').filter('.'+this.value).show('3000');
            }
        });
        
        //magnificPopup
        $('.popup-gallery').magnificPopup({
            delegate: 'a',
            type: 'image',
            mainClass: 'mfp-img-mobile',
            gallery: {
                enabled: true,
                navigateByImgClick: true,
                preload: [0,1]
            },
        });

        //magnificPopup Video
        $('.popup-youtube a').magnificPopup({
            disableOn: 700,
            type: 'iframe',
            mainClass: 'mfp-fade',
            removalDelay: 160,
            preloader: false,
            fixedContentPos: true
        });
    });

}
}
</script>   