<template>
<div class="">
        <!--End Header -->

        <!-- Banner -->
        <section class="slider py-0">
            <div id="home-slider" class="swiper-container">
                <div class="swiper-wrapper">
                    <div class="swiper-slide bg-cover overlay-fill" :style="{'background-image': 'url(' + require('../assets/images/news2.jpg') + ')'}">
                        <div class="container">
                            <div class="row justify-content-center">
                                <div class="col-12 col-lg-8">
                                    <div class="slider-content text-center text-white">
                                        <h2 class="text-white">Welcome To Forward In Faith Ministries</h2>
                                        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula dolor. Aenean  massa. Cum sociis natoque penatibus et magnis.Lorem ipsum dolor sit amet, consectetuer adipiscing elit. </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide bg-cover overlay-fill" :style="{'background-image': 'url(' + require('../assets/images/news1.jpg') + ')'}">
                        <div class="container">
                            <div class="row justify-content-center">
                                <div class="col-12 col-lg-8">
                                    <div class="slider-content text-center text-white">
                                        <h2 class="text-white">Welcome To Forward In Faith Ministries</h2>
                                        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula dolor. Aenean  massa. Cum sociis natoque penatibus et magnis.Lorem ipsum dolor sit amet, consectetuer adipiscing elit. </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide bg-cover overlay-fill" :style="{'background-image': 'url(' + require('../assets/images/news3.jpg') + ')'}">
                        <div class="container">
                            <div class="row justify-content-center">
                                <div class="col-12 col-lg-8">
                                    <div class="slider-content text-center text-white">
                                        <h2 class="text-white">Welcome To Forward In Faith Ministries</h2>
                                        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula dolor. Aenean  massa. Cum sociis natoque penatibus et magnis.Lorem ipsum dolor sit amet, consectetuer adipiscing elit. </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Add Arrows -->
                <div class="swiper-button-next"><i class="fa fa-angle-double-right"></i></div>
                <div class="swiper-button-prev"><i class="fa fa-angle-double-left"></i></div>
            </div>
        </section>
        <!-- End Banner -->

        <!-- Service -->
        <section class="servicesec pt-0 bg-light">
            <div class="container">
                <div class="row">
                    <div class="col-12 col-md-12">
                        <div id="service-slider" class="swiper-container">
                            <div class="swiper-wrapper">
                                <div class="swiper-slide">
                                    <a href="#">
                                        <div class="service-block bg-cover" :style="{'background-image': 'url(' + require('../assets/images/news2.jpg') + ')'}">
                                            <div class="service-content text-center text-white position-relative">
                                                <h5 class="mb-0">Upcoming Event & Updates</h5>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <div class="swiper-slide">
                                    <a href="#">
                                        <div class="service-block bg-cover" :style="{'background-image': 'url(' + require('../assets/images/news1.jpg') + ')'}">
                                            <div class="service-content text-center text-white position-relative">
                                                <h5 class="mb-0">Latest Gallery</h5>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <div class="swiper-slide">
                                    <a href="#">
                                        <div class="service-block bg-cover" :style="{'background-image': 'url(' + require('../assets/images/news3.jpg') + ')'}">
                                            <div class="service-content text-center text-white position-relative">
                                                <h5 class="mb-0">Latest Videos</h5>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <div class="swiper-slide">
                                    <a href="#">
                                        <div class="service-block bg-cover" :style="{'background-image': 'url(' + require('../assets/images/news2.jpg') + ')'}">
                                            <div class="service-content text-center text-white position-relative">
                                                <h5 class="mb-0">Upcoming Event & Updates</h5>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <div class="swiper-slide">
                                    <a href="#">
                                        <div class="service-block bg-cover" :style="{'background-image': 'url(' + require('../assets/images/news1.jpg') + ')'}">
                                            <div class="service-content text-center text-white position-relative">
                                                <h5 class="mb-0">Latest Gallery</h5>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <!-- Add Pagination -->
                            <div class="swiper-pagination"></div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Banner -->

        <!-- Main-content -->
        <section class="maincontent">
            <div class="container">
                <div class="row">
                    <div class="col-12 col-lg-6">
                        <div class="card rounded-0 text-center main-block">
                            <div class="card-header rounded-0 bg-primary py-3"><h5 class="mb-0 text-white">Founder & President</h5></div>
                            <div class="card-body">
                                <div class="president-image mb-4">
                                    <img src="../assets/images/article.jpg" alt="" class="img-fluid image-md" />
                                </div>
                                <div class="president-image">
                                    <h5 class="mb-2">Message From Founder & President</h5>
                                    <span>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem.</span>
                                </div>
                            </div>
                            <div class="card-footer font-italic border-0">
                                Overseer Danial And Rumbi Makuware National Administrator’s Senior Pastors Of Fifmi Church In Australia
                            </div>
                        </div>
                        <div class="card rounded-0 text-center main-block border-0">
                            <div class="card-header rounded-0 bg-primary py-3"><h5 class="mb-0 text-white">Founder & President</h5>
                            </div>
                            <div class="card-body p-0">
                                <div id="testimonial-slider" class="swiper-container">
                                    <div class="swiper-wrapper">
                                        <div class="swiper-slide">
                                            <div class="quote"><i class="fa fa-quote-left fa-4x text-primary"></i></div>
                                            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.Lorem ipsum dolor sit amet, consectetuer adipiscing elit.</p>
                                            <div class="test-author">
                                                <span>Client Name:</span>
                                                <h6 class="mb-0 author-name">Jonathan Anderson</h6>
                                            </div>
                                        </div>
                                        <div class="swiper-slide">
                                            <div class="quote"><i class="fa fa-quote-left fa-4x text-primary"></i></div>
                                            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.Lorem ipsum dolor sit amet, consectetuer adipiscing elit.</p>
                                            <div class="test-author">
                                                <span>Client Name:</span>
                                                <h6 class="mb-0 author-name">Robin Jack.</h6>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Add Arrows -->
                                    <div class="swiper-button-prev"><i class="fa fa-angle-double-left"></i></div>
                                    <div class="swiper-button-next"><i class="fa fa-angle-double-right"></i></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-lg-6">
                        <div class="row">
                            <div class="col-12 col-md-6 col-lg-12 col-xl-6 mb-4">
                                <ul class="list-group mb-0 visit-list">
                                    <li class="list-group-item rounded-0">
                                        <a href="#" class="d-flex align-items-center">
                                            <div class="visit-icon mr-3">
                                                <img src="../assets/images/world.png" alt="" class="img-fluid" />
                                            </div>
                                            <div class="visit-title">Visit our Website</div>
                                        </a>
                                    </li>
                                    <li class="list-group-item rounded-0">
                                        <a href="#" class="d-flex align-items-center">
                                            <div class="visit-icon mr-3">
                                                <img src="../assets/images/tv.png" alt="" class="img-fluid" />
                                            </div>
                                            <div class="visit-title">Ezekiel Tv</div>
                                        </a>
                                    </li>
                                    <li class="list-group-item rounded-0">
                                        <a href="#" class="d-flex align-items-center">
                                            <div class="visit-icon mr-3">
                                                <img src="../assets/images/user.png" alt="" class="img-fluid" />
                                            </div>
                                            <div class="visit-title">Conferences</div>
                                        </a>
                                    </li>
                                    <li class="list-group-item rounded-0">
                                        <a href="#" class="d-flex align-items-center">
                                            <div class="visit-icon mr-3">
                                                <img src="../assets/images/donation.png" alt="" class="img-fluid" />
                                            </div>
                                            <div class="visit-title">Donations</div>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                            <div class="col-12 col-md-6 col-lg-12 col-xl-6 mb-4">
                                <ul class="list-group mb-0 visit-list">
                                    <li class="list-group-item rounded-0">
                                        <div class="date-wrapper">
                                            <div class="date-box mr-3 text-center float-left">
                                                <span class="month bg-primary text-white d-block">Oct</span>
                                                <h5 class="mb-0 p-1 date">02</h5>
                                            </div>
                                            <div class="date-title"><a href="#" class="text-light">Social Networking for charity</a></div>
                                        </div>
                                    </li>
                                    <li class="list-group-item rounded-0">
                                        <div class="date-wrapper">
                                            <div class="date-box mr-3 text-center float-left">
                                                <span class="month bg-primary text-white d-block">Sep</span>
                                                <h5 class="mb-0 p-1 date">05</h5>
                                            </div>
                                            <div class="date-title"><a href="#" class="text-light">Organising a charity Parachute Jump</a></div>
                                        </div>
                                    </li>
                                    <li class="list-group-item rounded-0">
                                        <div class="date-wrapper">
                                            <div class="date-box mr-3 text-center float-left">
                                                <span class="month bg-primary text-white d-block">Nov</span>
                                                <h5 class="mb-0 p-1 date">08</h5>
                                            </div>
                                            <div class="date-title"><a href="#" class="text-light">The General Theological Seminary</a></div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="card rounded-0 text-center main-block">
                            <div class="card-header rounded-0 bg-primary py-3"><h5 class="mb-0 text-white">The Senior Pastors</h5></div>
                            <div class="card-body">
                                <div class="president-image mb-4">
                                    <img src="../assets/images/Pastor.jpg" alt="" class="img-fluid image-md" />
                                </div>
                                <div class="president-image">
                                    <h5 class="mb-2">Message From The Senior Pastors</h5>
                                    <span>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Lorem ipsum dolor sit amet, adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Lorem ipsum dolor sit amet, consectetuer adipiscing elit.</span>
                                </div>
                            </div>
                            <div class="card-footer font-italic border-0">
                                Overseer Danial And Rumbi Makuware National Administrator’s Senior Pastors Of Fifmi Church In Australia
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Main-content -->

        <!-- Footer -->
        </div>
        
  
</template>


<script>

// @ is an alias to /src
import Swiper from '../assets/js/swiper.min.js'
export default {
  name: 'Hello',
  data(){
 return {
   swiper: "",
   serviceSlider: "",
   testimonialSlider: "",
   marquee: "",
 }
},
  mounted() {
      //Home Slider
            this.swiper = new Swiper('#home-slider', {
                effect: 'fade',
                navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
              },
            });
            
              //Service Slider
            this.serviceSlider = new Swiper('#service-slider', {
                pagination: {
                    el: '.swiper-pagination',
                    clickable: true,
                },
                breakpoints: {
                    681: {
                      slidesPerView: 2,
                    },
                    1024: {
                      slidesPerView: 3,
                    },
                }
            });

          //Home Slider
             this.testimonialSlider = new Swiper('#testimonial-slider', {
                navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
              },
            });
   },
metaInfo: {
    link: [
      {
        rel: "stylesheet",
        href: "https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"
      },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css?family=Muli:200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap"
      },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css?family=Roboto+Slab:100,200,300,400,500,600,700,800,900&display=swap"
      },
    ]
}
}
</script>
