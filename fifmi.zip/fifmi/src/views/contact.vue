<template>
<div>
 <!-- Map -->
        <section class="mapsec py-0">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d30370.132662389762!2d30.983375800105165!3d-17.919715932828087!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1931a2323bf6f4e1%3A0x62218f4f6d7f532b!2sWaterfalls%2C%20Harare%2C%20Zimbabwe!5e0!3m2!1sen!2sin!4v1583227629394!5m2!1sen!2sin" width="100%" height="350" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
        </section>
        <!-- End Map -->

        <!-- Contact -->
        <section class="contactdetailsec py-5">
            <div class="container">
                <div class="row">
                    <div class="col-12 col-md-12 mb-4">
                        <div class="heading text-center">
                            <h3>Contact Details</h3>
                            <hr class="brd-primary">
                        </div>
                    </div>
                </div>
                <div class="row no-gutters">
                    <div class="col-12 col-md-6 col-lg-3">
                        <div class="contact-block text-center">
                            <div class="contact-icon rounded-50 mx-auto mb-3">
                                <i class="fa fa-map-marker"></i>
                            </div>
                            <div class="contact-txt text-dark">
                                <span>13 A Powell Rd, Waterfalls, Harare, Zimbabwe</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-6 col-lg-3">
                        <div class="contact-block text-center">
                            <div class="contact-icon rounded-50 mx-auto mb-3">
                                <i class="fa fa-phone"></i>
                            </div>
                            <div class="contact-txt text-dark">
                                <span><a href="tel:+263 8677 004035" class="text-dark">+263 8677 004035</a></span>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-6 col-lg-3">
                        <div class="contact-block text-center">
                            <div class="contact-icon rounded-50 mx-auto mb-3">
                                <i class="fa fa-fax"></i>
                            </div>
                            <div class="contact-txt text-dark">
                                <span><a href="tel:+44(0)208 997 2725" class="text-dark">+44(0)208 997 2725</a></span>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-6 col-lg-3">
                        <div class="contact-block text-center">
                            <div class="contact-icon rounded-50 mx-auto mb-3">
                                <i class="fa fa-envelope"></i>
                            </div>
                            <div class="contact-txt text-dark">
                                <span><a href="mailto:info@fifmi.org" class="text-dark">info@fifmi.org</a></span>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-6 col-lg-3">
                        <div class="contact-block text-center">
                            <div class="contact-icon rounded-50 mx-auto mb-3">
                                <i class="fa fa-map-marker"></i>
                            </div>
                            <div class="contact-txt text-dark">
                                <span>UK/European Headquarters 58 Hainge Road | Tividale, Oldbury | West Midlands | UK | B69 2PB</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-6 col-lg-3">
                        <div class="contact-block text-center">
                            <div class="contact-icon rounded-50 mx-auto mb-3">
                                <i class="fa fa-phone"></i>
                            </div>
                            <div class="contact-txt text-dark">
                                <span><a href="tel:+44(0)121 557 6508" class="text-dark">+44(0)121 557 6508</a></span>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-6 col-lg-3">
                        <div class="contact-block text-center">
                            <div class="contact-icon rounded-50 mx-auto mb-3">
                                <i class="fa fa-fax"></i>
                            </div>
                            <div class="contact-txt text-dark">
                                <span><a href="tel:+44(0)208 997 2725" class="text-dark">+44(0)208 997 2725</a></span>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-6 col-lg-3">
                        <div class="contact-block text-center">
                            <div class="contact-icon rounded-50 mx-auto mb-3">
                                <i class="fa fa-envelope"></i>
                            </div>
                            <div class="contact-txt text-dark">
                                <span><a href="mailto:info@fifmi.org" class="text-dark">info@fifmi.org</a></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Contact -->

        <!-- Contact -->
        <section class="contactdetailsec py-5">
            <div class="container">
                <div class="row">
                    <div class="col-12 col-md-12 mb-4">
                        <div class="heading">
                            <h3>Send Us A Message</h3>
                            <hr class="brd-primary ml-0">
                        </div>
                    </div>
                </div>
                <form class="contact-form">
                    <div class="row">
                        <div class="col-12 col-md-6">
                            <div class="form-group">
                                <label class="text-dark">First Name</label>
                                <input type="text" class="form-control">
                            </div>
                        </div>
                        <div class="col-12 col-md-6">
                            <div class="form-group">
                                <label class="text-dark">Last Name</label>
                                <input type="text" class="form-control">
                            </div>
                        </div>
                        <div class="col-12 col-md-6">
                            <div class="form-group">
                                <label class="text-dark">Email Address</label>
                                <input type="email" class="form-control">
                            </div>
                        </div>
                        <div class="col-12 col-md-6">
                            <div class="form-group">
                                <label class="text-dark">Address</label>
                                <input type="text" class="form-control">
                            </div>
                        </div>
                        <div class="col-12 col-md-6">
                            <div class="form-group">
                                <label class="text-dark">Phone Number</label>
                                <input type="text" class="form-control">
                            </div>
                        </div>
                        <div class="col-12 col-md-6">
                            <div class="form-group">
                                <label class="text-dark">City</label>
                                <input type="text" class="form-control">
                            </div>
                        </div>
                        <div class="col-12 col-md-6">
                            <div class="form-group">
                                <label class="text-dark">State / Province</label>
                                <input type="text" class="form-control">
                            </div>
                        </div>
                        <div class="col-12 col-md-6">
                            <div class="form-group">
                                <label class="text-dark">Country</label>
                                <input type="text" class="form-control">
                            </div>
                        </div>
                        <div class="col-12 col-md-12">
                            <div class="form-group">
                                <label class="text-dark">Select Category</label>
                                <select class="form-control">
                                    <option value="General">General</option>
                                    <option value="General">General</option>
                                    <option value="General">General</option>
                                    <option value="General">General</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-12 col-md-12">
                            <div class="form-group">
                                <label class="text-dark">Message</label>
                                <textarea class="form-control"></textarea>
                            </div>
                        </div>
                        <div class="col-12 col-md-12">
                            <button type="submit" class="btn btn-primary btn-lg rounded-0 text-uppercase">Submit</button>
                        </div>
                    </div>
                </form>
            </div>
        </section>
        <!-- End Contact -->


</div>
</template>

<script>

</script>