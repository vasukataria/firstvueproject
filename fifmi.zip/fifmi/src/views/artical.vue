<template>
<div class="">
 <!-- Page Inner -->
        <section class="innersec">
            <div class="container">
                <div class="row">
                    <div class="col-12 col-md-12">
                        <div class="toptitle text-center">
                            <h2>Articles</h2>
                            <nav>
                                <ol class="breadcrumb bg-transparent p-0 justify-content-center font-weight-bold">
                                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                                    <li class="breadcrumb-item active">Articles</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Page Inner -->

        <!-- Article -->
        <section class="articlesec py-5">
            <div class="container">
                <div class="row">
                    <div class="col-12 col-lg-12">
                        <div class="heading mb-4">
                            <h2>Latest Articles</h2>
                            <hr class="brd-primary ml-0">
                        </div>
                    </div>
                    <div class="col-12 col-lg-9 mb-5 mb-lg-0">
                        <article class="article-block">
                            <div class="articleimg shrink-effect">
                                <img src="../assets/images/article.jpg" class="img-fluid rounded" alt="" />
                            </div>
                            <div class="article-content">
                                <a href="#"><h5 class="mb-1">Apostles Update Week 27</h5></a>
                                <div class="article-author text-dark py-2 font-weight-bold">
                                    <span><i class="fa fa-user-o"></i> by drlaverne</span>
                                    <span><i class="fa fa-calendar"></i> July 16 2018</span>
                                </div>
                                <p class="mb-1">Dear Friends Bindura Night of Miracles3000 people thronged the cathedral and rays of prayer and joy could be felt even from afar. Many internationals and kingdom seekers also came to pray for the Apostles of Jesus Christ Prof EH Guti and Dr. Eunor Guti. Some notable miracles:98 souls were saved as they received Jesus Christ as personal Saviour.one woman was healed of...</p>
                                <a href="#">Continue Reading <i class="fa fa-long-arrow-right pl-1"></i></a>
                            </div>
                        </article>
                        <article class="article-block">
                            <div class="articleimg shrink-effect">
                                <img src="../assets/images/article.jpg" class="img-fluid rounded" alt="" />
                            </div>
                            <div class="article-content">
                                <a href="#"><h5 class="mb-1">Apostles Update Week 27</h5></a>
                                <div class="article-author text-dark py-2 font-weight-bold">
                                    <span><i class="fa fa-user-o"></i> by drlaverne</span>
                                    <span><i class="fa fa-calendar"></i> July 16 2018</span>
                                </div>
                                <p class="mb-1">Dear Friends Bindura Night of Miracles3000 people thronged the cathedral and rays of prayer and joy could be felt even from afar. Many internationals and kingdom seekers also came to pray for the Apostles of Jesus Christ Prof EH Guti and Dr. Eunor Guti. Some notable miracles:98 souls were saved as they received Jesus Christ as personal Saviour.one woman was healed of...</p>
                                <a href="#">Continue Reading <i class="fa fa-long-arrow-right pl-1"></i></a>
                            </div>
                        </article>
                        <article class="article-block">
                            <div class="articleimg shrink-effect">
                                <img src="../assets/images/article.jpg" class="img-fluid rounded" alt="" />
                            </div>
                            <div class="article-content">
                                <a href="#"><h5 class="mb-1">Apostles Update Week 27</h5></a>
                                <div class="article-author text-dark py-2 font-weight-bold">
                                    <span><i class="fa fa-user-o"></i> by drlaverne</span>
                                    <span><i class="fa fa-calendar"></i> July 16 2018</span>
                                </div>
                                <p class="mb-1">Dear Friends Bindura Night of Miracles3000 people thronged the cathedral and rays of prayer and joy could be felt even from afar. Many internationals and kingdom seekers also came to pray for the Apostles of Jesus Christ Prof EH Guti and Dr. Eunor Guti. Some notable miracles:98 souls were saved as they received Jesus Christ as personal Saviour.one woman was healed of...</p>
                                <a href="#">Continue Reading <i class="fa fa-long-arrow-right pl-1"></i></a>
                            </div>
                        </article>
                        <article class="article-block">
                            <div class="articleimg shrink-effect">
                                <img src="../assets/images/article.jpg" class="img-fluid rounded" alt="" />
                            </div>
                            <div class="article-content">
                                <a href="#"><h5 class="mb-1">Apostles Update Week 27</h5></a>
                                <div class="article-author text-dark py-2 font-weight-bold">
                                    <span><i class="fa fa-user-o"></i> by drlaverne</span>
                                    <span><i class="fa fa-calendar"></i> July 16 2018</span>
                                </div>
                                <p class="mb-1">Dear Friends Bindura Night of Miracles3000 people thronged the cathedral and rays of prayer and joy could be felt even from afar. Many internationals and kingdom seekers also came to pray for the Apostles of Jesus Christ Prof EH Guti and Dr. Eunor Guti. Some notable miracles:98 souls were saved as they received Jesus Christ as personal Saviour.one woman was healed of...</p>
                                <a href="#">Continue Reading <i class="fa fa-long-arrow-right pl-1"></i></a>
                            </div>
                        </article>
                        <article class="article-block">
                            <div class="articleimg shrink-effect">
                                <img src="../assets/images/article.jpg" class="img-fluid rounded" alt="" />
                            </div>
                            <div class="article-content">
                                <a href="#"><h5 class="mb-1">Apostles Update Week 27</h5></a>
                                <div class="article-author text-dark py-2 font-weight-bold">
                                    <span><i class="fa fa-user-o"></i> by drlaverne</span>
                                    <span><i class="fa fa-calendar"></i> July 16 2018</span>
                                </div>
                                <p class="mb-1">Dear Friends Bindura Night of Miracles3000 people thronged the cathedral and rays of prayer and joy could be felt even from afar. Many internationals and kingdom seekers also came to pray for the Apostles of Jesus Christ Prof EH Guti and Dr. Eunor Guti. Some notable miracles:98 souls were saved as they received Jesus Christ as personal Saviour.one woman was healed of...</p>
                                <a href="#">Continue Reading <i class="fa fa-long-arrow-right pl-1"></i></a>
                            </div>
                        </article>
                        <nav>
                            <ul class="pagination mb-0 justify-content-center">
                                <li class="page-item"><a class="page-link" href="#">Previous</a></li>
                                <li class="page-item active"><a class="page-link" href="#">1</a></li>
                                <li class="page-item"><a class="page-link" href="#">2</a></li>
                                <li class="page-item"><a class="page-link" href="#">3</a></li>
                                <li class="page-item"><a class="page-link" href="#">Next</a></li>
                            </ul>
                        </nav>
                    </div>
                    <div class="col-12 col-lg-3">
                        <div class="right-title">
                            <h5>Ezekiel Tv</h5>
                            <a href="#" class="right-newsimg"><img src="images/news.jpg" alt="" class="img-fluid" /></a>
                        </div>
                        <hr>
                        <div class="eventdiv">
                            <a href="#"><img src="../assets/images/event.jpg" alt="" class="img-fluid" /></a>
                        </div>
                        <hr>
                        <div class="right-title">
                            <h5>Account Login</h5>
                            <form class="login-form">
                                <div class="form-group position-relative">
                                    <input type="email" name="email" placeholder="Email" class="form-control pr-4" />
                                    <span class="formicon"><i class="fa fa-user"></i></span>
                                </div>
                                <div class="form-group position-relative">
                                    <input type="password" name="password" placeholder="Password" class="form-control pr-4" />
                                    <span class="formicon"><i class="fa fa-lock"></i></span>
                                </div>
                                <div class="form-group-btn">
                                    <input type="submit" value="Login" class="btn btn-primary text-uppercase btn-block rounded-0 mb-1" />
                                </div>
                            </form>
                            <div class="text-dark text-center">
                                Create an account <a href="#"><u>Register</u></a>
                            </div>
                        </div>
                        <hr>
                        <div class="right-title">
                            <h5>Recent Comments</h5>
                            <ul class="list-unstyled mb-0 comment-list">
                                <li>
                                    <a href="#" class="text-light">
                                        <div class="commentimg shrink-effect float-left mr-3">
                                            <img src="images/comment.jpg" alt="" class="img-fluid" />
                                        </div>
                                        <div class="comment-txt">
                                            <h6 class="mb-1">Glory be to the Almighty God</h6>
                                            <span><i class="fa fa-calendar"></i> 2 years 45 weeks ago</span>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" class="text-light">
                                        <div class="commentimg shrink-effect float-left mr-3">
                                            <img src="../assets/images/comment.jpg" alt="" class="img-fluid" />
                                        </div>
                                        <div class="comment-txt">
                                            <h6 class="mb-1">Glory be to the Almighty God</h6>
                                            <span><i class="fa fa-calendar"></i> 2 years 45 weeks ago</span>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" class="text-light">
                                        <div class="commentimg shrink-effect float-left mr-3">
                                            <img src="../assets/images/comment.jpg" alt="" class="img-fluid" />
                                        </div>
                                        <div class="comment-txt">
                                            <h6 class="mb-1">Glory be to the Almighty God</h6>
                                            <span><i class="fa fa-calendar"></i> 2 years 45 weeks ago</span>
                                        </div>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Article -->
        </div>
  
</template>


<script>

// @ is an alias to /src
import GreenAudioPlayer from '../assets/js/green-audio-player.js'
import Swiper from '../assets/js/swiper.min.js'
export default {
  name: 'Hello',
  data(){
 return {
   swiper: "",
   serviceSlider: "",
   testimonialSlider: "",
   marquee: "",
 }
},
  mounted() {
   document.addEventListener('DOMContentLoaded', function() {
        new GreenAudioPlayer('.ready-player-1');
    });
      //Home Slider
            this.swiper = new Swiper('#home-slider', {
                effect: 'fade',
                navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
              },
            });
            
              //Service Slider
            this.serviceSlider = new Swiper('#service-slider', {
                pagination: {
                    el: '.swiper-pagination',
                    clickable: true,
                },
                breakpoints: {
                    681: {
                      slidesPerView: 2,
                    },
                    1024: {
                      slidesPerView: 3,
                    },
                }
            });

          //Home Slider
             this.testimonialSlider = new Swiper('#testimonial-slider', {
                navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
              },
            });

            //Top Slider
            this.marquee = new Swiper('#marquee', {
              effect: 'fade',
              autoplay: {
                delay: 1500,
                disableOnInteraction: false,
              },
            });
   },
metaInfo: {
    link: [
      {
        rel: "stylesheet",
        href: "https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"
      },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css?family=Muli:200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap"
      },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css?family=Roboto+Slab:100,200,300,400,500,600,700,800,900&display=swap"
      },
    ]
}
}
</script>
