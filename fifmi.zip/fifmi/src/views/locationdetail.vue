<template>
<div>
  <!-- Page Inner -->
        <section class="innersec">
            <div class="container">
                <div class="row">
                    <div class="col-12 col-md-12">
                        <div class="toptitle text-center">
                            <h2>Location Detail</h2>
                            <nav>
                                <ol class="breadcrumb bg-transparent p-0 justify-content-center font-weight-bold">
                                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                                    <li class="breadcrumb-item active">Location Detail</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Page Inner -->

        <!-- Bible -->
        <section class="biblesec py-5">
            <div class="container">
                <div class="row">
                    <div class="col-12 col-lg-9 mb-5 mb-lg-0">
                        <div class="bible">
                            <h5>India</h5>
                            <div class="text-dark">
                                <span class="pr-2"><i class="fa fa-user-o"></i> admin on</span>
                                <span class="pr-2"><i class="fa fa-calendar"></i> June 12, 2011</span>
                                <span class="pr-2"><i class="fa fa-clock-o"></i> 16:48 </span>
                            </div>
                            <hr>
                            <p>FIFMI church was registered in India in June, 2007 by the servant and apostle of God, Archbishop Dr E.H. Guti. Faithful workers in the Lord came to India to support the establishment of the work, and by the grace of God, the church was started with miracles following in the lives of the people who were touched by the ministry.</p>
                            <p>Pastors who ministered in India include Mr. and Mrs Saidi, Mr. and Mrs. Gudyanga, Mr. and Mrs. Mutumbwa, Mr. and Mrs. Christmas and student pastor Danrooj from Mauritius. As of October 2008, the Church has grown miraculously, with Sunday services averaging 85 people, and a membership of 100. The membership is growing remarkably, and every Sunday new locals are giving their lives to Jesus</p>
                            <p>Another center was opened up where people meet on Wednesday to hear the word of God. The church in India is a multi-national gathering with a diversity of people hungry for the word of God, in fulfillment of the vision that God gave to His servant Dr. Guti. Countries represented include India, Zimbabwe, Kenya, Uganda,Tanzania, Botswana, Malawi, Lesotho, Namibia, Nigeria, Ivory Coast, Angola and DRC</p>
                        </div>
                    </div>
                    <div class="col-12 col-lg-3">
                        <div class="right-title">
                            <h5>Ezekiel Tv</h5>
                            <a href="#" class="right-newsimg"><img src="../assets/images/news.jpg" alt="" class="img-fluid" /></a>
                        </div>
                        <hr>
                        <div class="eventdiv">
                            <a href="#"><img src="../assets/images/event.jpg" alt="" class="img-fluid" /></a>
                        </div>
                        <hr>
                        <div class="right-title">
                            <h5>Account Login</h5>
                            <form class="login-form">
                                <div class="form-group position-relative">
                                    <input type="email" name="email" placeholder="Email" class="form-control pr-4" />
                                    <span class="formicon"><i class="fa fa-user"></i></span>
                                </div>
                                <div class="form-group position-relative">
                                    <input type="password" name="password" placeholder="Password" class="form-control pr-4" />
                                    <span class="formicon"><i class="fa fa-lock"></i></span>
                                </div>
                                <div class="form-group-btn">
                                    <input type="submit" value="Login" class="btn btn-primary text-uppercase btn-block rounded-0 mb-1" />
                                </div>
                            </form>
                            <div class="text-dark text-center">
                                Create an account <a href="#"><u>Register</u></a>
                            </div>
                        </div>
                        <hr>
                        <div class="right-title">
                            <h5>Recent Comments</h5>
                            <ul class="list-unstyled mb-0 comment-list">
                                <li>
                                    <a href="#" class="text-light">
                                        <div class="commentimg shrink-effect float-left mr-3">
                                            <img src="../assets/images/comment.jpg" alt="" class="img-fluid" />
                                        </div>
                                        <div class="comment-txt">
                                            <h6 class="mb-1">Glory be to the Almighty God</h6>
                                            <span><i class="fa fa-calendar"></i> 2 years 45 weeks ago</span>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" class="text-light">
                                        <div class="commentimg shrink-effect float-left mr-3">
                                            <img src="../assets/images/comment.jpg" alt="" class="img-fluid" />
                                        </div>
                                        <div class="comment-txt">
                                            <h6 class="mb-1">Glory be to the Almighty God</h6>
                                            <span><i class="fa fa-calendar"></i> 2 years 45 weeks ago</span>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" class="text-light">
                                        <div class="commentimg shrink-effect float-left mr-3">
                                            <img src="../assets/images/comment.jpg" alt="" class="img-fluid" />
                                        </div>
                                        <div class="comment-txt">
                                            <h6 class="mb-1">Glory be to the Almighty God</h6>
                                            <span><i class="fa fa-calendar"></i> 2 years 45 weeks ago</span>
                                        </div>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Bible -->
</div>
</template>

<script>
export default{
}
</script>